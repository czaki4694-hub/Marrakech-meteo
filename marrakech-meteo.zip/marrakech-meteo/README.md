# طقس مراكش (Android)
تطبيق Android خفيف: WebView + HTML/JS صافي. البيانات من Open-Meteo، والرادار من RainViewer، والخريطة Leaflet + OSM/CARTO.
البناء: GitHub Actions ← `gradle assembleDebug` ← APK فـ Artifacts.
